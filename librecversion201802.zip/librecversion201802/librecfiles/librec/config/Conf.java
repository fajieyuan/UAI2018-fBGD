package com.gla.uni.config;

public class Conf {
	public static final String comma=",";
	public static final String vl="\\|";
	public static final String space=" ";
	public static final String tab="\t";
	public static final String colon=":";
	public static final String slash="/";
	public static final String unline="_";
}
