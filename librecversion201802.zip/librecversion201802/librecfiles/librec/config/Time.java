package com.gla.uni.config;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class Time {
	public static void main(String[] args) throws ParseException {
		getTimeDis("2012-04-21 23:05:22");
	}
	/**
	 * 判断当前日期是星期几<br>
	 * <br>
	 * 
	 * @param pTime
	 *            修要判断的时间<br>
	 * @return dayForWeek 判断结果<br>
	 * @Exception 发生异常<br>
	 */
	public static int dayForWeek(String pTime) throws Exception {
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		Calendar c = Calendar.getInstance();
		c.setTime(format.parse(pTime));
		int dayForWeek = 0;
		if (c.get(Calendar.DAY_OF_WEEK) == 1) {
			dayForWeek = 7;
		} else {
			dayForWeek = c.get(Calendar.DAY_OF_WEEK) - 1;
		}
		return dayForWeek;
	}
/**
 * 23-5       -0
 * 5-10       -1  breakfast
 * 10-11      -2  
 * 11-14      -3  lunch
 * 14-16      -4    
 * 16-23      -5  dinner
 * @return
 * @throws ParseException 
 */
	public static int getTimeDis(String data) throws ParseException
	{
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date=df.parse(data);
		
		int hour= date.getHours();
		int dis=0;
		if (hour >= 23 && hour < 5) {
			dis=0;
		}
		if (hour >= 5 && hour < 10) {
			dis=1;
		}
		if (hour >= 10 && hour < 11) {
			dis=2;
		}
		if (hour >= 11 && hour < 14) {
			dis=3;
		}
		if (hour >= 14 && hour < 16) {
			dis=4;
		}
		if (hour >= 16 && hour < 23) {
			dis=5;
		}
		return dis;
	}
}
