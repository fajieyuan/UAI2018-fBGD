// Copyright (C) 2014 Guibing Guo
//
// This file is part of LibRec.
//
// LibRec is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// LibRec is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with LibRec. If not, see <http://www.gnu.org/licenses/>.
//

package librec.ranking;

import java.util.List;


import librec.data.DenseMatrix;
import librec.data.DenseVector;
import librec.data.SparseMatrix;
import librec.data.SparseVector;
import librec.fajie.MProUtil;
import librec.intf.IterativeRecommender;
import happy.coding.io.Strings;
import happy.coding.math.Randoms;
/**
 * 
 * Rendle et al., <strong>.
 * 
 * @author fajieyuan
 * 
 * Note for music recommendation     
 */
public class LambdaMF extends IterativeRecommender {
	private int lossf;
	private double maxloss;
	private float epsilon;
	public LambdaMF(SparseMatrix trainMatrix, SparseMatrix testMatrix, int fold) {
		super(trainMatrix, testMatrix, fold);
		isRankingPred = true;
		lossf = algoOptions.getInt("-lossf",2);
		epsilon=algoOptions.getFloat("-epsilon");
	}
	
	@Override
	protected void initModel() throws Exception {
		super.initModel();
		userCache = trainMatrix.rowCache(cacheSpec);
		for (int i = 1; i < numItems; i++) {
			maxloss += 1.0 / i;
		}
	}

	@Override
	protected void buildModel() throws Exception {
		
		for (int iter = 1; iter <= numIters; iter++) {
			loss = 0;
			for (int s = 0, smax = numUsers * 300; s < smax; s++) {
				// randomly draw (u, i, j)
				int u = 0, i = 0, j = 0;
				int N=0;
				int Y=0;
				double xui=0;
				double xuj=0;
				while (true) {
					u = Randoms.uniform(numUsers);
					SparseVector pu = userCache.get(u);

					if (pu.getCount() == 0)
						continue;

					int[] is = pu.getIndex();
					i = is[Randoms.uniform(is.length)];
					boolean con1 = false;
					N = 0;
					Y = 0;
					xui = predict(u, i);
					do {
						N += 1;
						j = Randoms.uniform(numItems);
						xuj = predict(u, j);
						con1 = xuj > xui - epsilon;
						Y = numItems - is.length;
						if (N > numItems - is.length - 1)
							break;
					} while (pu.contains(j) || !con1);

					break;
				}
				// update parameters
				double xuij = xui - xuj;
	
				double z=1;
				double cmg=0;
				
				double l_rank=Math.floor((Y-1)/N);
				double l_loss=0;
				for (int k = 1; k <= l_rank; k++) {
					l_loss += 1.0 / k;
				}
				l_loss/=maxloss;
				cmg=getGradMag(lossf, xuij);
				
				cmg=cmg*l_loss;
				double vals = -Math.log(g(xuij));//Note I use logistic loss as a surrogate for other losses
				loss += vals;
				
				for (int f = 0; f < numFactors; f++) {
					double puf = P.get(u, f);
					double qif = Q.get(i, f);
					double qjf = Q.get(j, f);
		
					P.add(u, f, lRate * (cmg * (qif - qjf) - regU * puf));
					Q.add(i, f, lRate * (cmg * puf - regI * qif));
					Q.add(j, f, lRate * (cmg * (-puf) - regI * qjf));
					loss += regU * puf * puf + regI * qif * qif + regI * qjf * qjf;
				}
			}
			if (isConverged(iter))
				break;

		}
	}

	@Override
	public String toString() {
		return Strings.toString(new Object[] {lossf,  epsilon, binThold, numFactors, initLRate,
				maxLRate, regU, regI, numIters }, ",");
	}
}
