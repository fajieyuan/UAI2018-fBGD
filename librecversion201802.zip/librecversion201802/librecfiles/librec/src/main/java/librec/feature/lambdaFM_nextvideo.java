// Copyright (C) 2014 Guibing Guo
//
// This file is part of LibRec.
//
// LibRec is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// LibRec is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with LibRec. If not, see <http://www.gnu.org/licenses/>.
//

package librec.feature;


import happy.coding.io.Strings;
import happy.coding.math.Randoms;
import librec.data.DenseVector;
import librec.data.SparseMatrix;
import librec.data.SparseVector;
import librec.fajie.MProUtil;


/**
 * 
 * YUAN et al., <strong>LambdaFM: Learning Optimal Ranking with Factorization Machines Using Lambda Surrogates</strong>, CIKM 2016.
 * @author fajie yuan
 */
public class lambdaFM_nextvideo extends FactMachine_UID {
	public static double max=Integer.MAX_VALUE;
	public static String colon=":";
	public static String comma=",";

	private int lossf;
	private double maxloss;
	private float epsilon;
	
	public lambdaFM_nextvideo(SparseMatrix trainMatrix, SparseMatrix testMatrix, int fold) {
		super(trainMatrix, testMatrix, fold);
		isRankingPred = true;
		lossf = algoOptions.getInt("-lossf");
		epsilon=algoOptions.getFloat("-epsilon");
//		initByNorm = true;
	}
	
	@Override
	protected void initModel() throws Exception {
		super.initModel();
		userCache = trainMatrix.rowCache(cacheSpec);
		for (int i = 1; i < numItems; i++) {
			maxloss += 1.0 / i;
		}
	}


	@Override
	protected void buildModel() throws Exception {

		DenseVector grad=new DenseVector(x_size);
		DenseVector grad_visited=new DenseVector(x_size);
		SparseVector x_i;
		SparseVector x_j;
		for (int iter = 1; iter <= numIters; iter++) {
			loss = 0;
			for (int s = 0, smax = numUsers * 300; s < smax; s++) {
				int u = 0, i = 0, j = 0;
				int N=0;
				int Y=0;
				double xui=0;
				double xuj=0;
				
				while (true) {
					u = Randoms.uniform(numUsers);
					SparseVector pu = userCache.get(u);
					
					x_i=new SparseVector(x_size);
					
					if (pu.getCount() == 0)
						continue;
					int[] is = pu.getIndex();
					i = is[Randoms.uniform(is.length)];

					boolean con1 = false;
					N = 0;
					Y = 0;
					double si=0;
					double sj=0;
					
					
					
					String userfield=rateDao.getUserId(u);
					int uid=Integer.parseInt(userfield.split("-")[0]);
					int premusicid=Integer.parseInt(userfield.split("-")[1]);
					

					//1-1000,2-16057,1,1241361476000
					x_i.set(uid, 1);//user
					x_i.set(premusicid, 1);
					x_i.set(i + PC, 1);
				
					
					
					
					
					xui = predict(x_i);
					do {
						N += 1;
						j = Randoms.uniform(numItems);
						x_j=new SparseVector(x_size);
						
						
						x_j.set(uid, 1);//user
						x_j.set(premusicid, 1);
						x_j.set(j + PC, 1);
						
						
						
						xuj = predict(x_j);
						con1 = xuj > xui - epsilon;
						Y = numItems - is.length;
						si = trainMatrix.get(u, i);
						sj = trainMatrix.get(u, j);

						if (N >=Y- 1)
							break;
					} while (!(con1&&(si> sj)));

					break;
				}

				double xuij = xui - xuj;
				DenseVector sum_pos=sum(x_i);// should be calculated by predict(x_i) to save time
				DenseVector sum_neg=sum(x_j);// should be calculated by predict(x_j) to save time
				double l_loss=0;
				double l_rank=Math.floor((Y-1)/N);
				for (int k = 1; k <= l_rank; k++) {
					l_loss += 1.0 / k;
				}
				l_loss/=maxloss;
				
				double cmg=0;
				cmg=getGradMag(lossf, xuij);
				cmg=cmg*l_loss;
				
				double vals = -Math.log(g(xuij));
				loss += vals;
				if (k1 == 1) {
					for (int c = 0; c < x_i.size(); c++) {
						int idx = x_i.getIndexList().get(c);
						grad.set(idx, 0);
						grad_visited.set(idx, 0);
					}
					for (int c = 0; c < x_j.size(); c++) {
						int idx = x_j.getIndexList().get(c);
						grad.set(idx, 0);
						grad_visited.set(idx, 0);
					}
					for (int c = 0; c < x_i.size(); c++) {
						int idx = x_i.getIndexList().get(c);
						grad.add(idx, x_i.get(idx));
					}
					for (int c = 0; c < x_j.size(); c++) {
						int idx = x_j.getIndexList().get(c);
						grad.add(idx, -x_j.get(idx));
					}
					
					for (int c = 0; c < x_i.size(); c++) {
						int idx = x_i.getIndexList().get(c);
						if(grad_visited.get(idx)==0)
						{
							w.add(idx,
									lRate
											* (cmg* (grad.get(idx) )-  regK1
													* w.get(idx)));
							grad_visited.set(idx, 1);
//							loss += regK1*w.get(idx)*w.get(idx);
						}
					}
					for (int c = 0; c < x_j.size(); c++) {
						int idx = x_j.getIndexList().get(c);
						if(grad_visited.get(idx)==0)
						{
							w.add(idx,
									lRate
											* (cmg* (grad.get(idx)) -  regK1
													* w.get(idx)));
							grad_visited.set(idx, 1);
//							loss += regK1*w.get(idx)*w.get(idx);
						}
					}
				}
				//Update v_ij
				if (k2 == 1) {
					for (int f = 0; f < numFactors; f++) {
						for (int c = 0; c < x_i.size(); c++) {
							int idx = x_i.getIndexList().get(c);
							grad.set(idx, 0);
							grad_visited.set(idx, 0);
						}
						for (int c = 0; c < x_j.size(); c++) {
							int idx = x_j.getIndexList().get(c);
							grad.set(idx, 0);
							grad_visited.set(idx, 0);
						}
						for (int c = 0; c < x_i.size(); c++) {
							int idx = x_i.getIndexList().get(c);
							grad.add(
									idx,
									sum_pos.get(f) * x_i.get(idx)
											- V.get(idx, f) * x_i.get(idx)
											* x_i.get(idx));
						}
						for (int c = 0; c < x_j.size(); c++) {
							int idx = x_j.getIndexList().get(c);
							grad.add(
									idx,
									-(sum_neg.get(f) * x_j.get(idx) - V.get(
											idx, f)
											* x_j.get(idx)
											* x_j.get(idx)));
						}
						
						for (int c = 0; c < x_i.size(); c++) {
							int idx=x_i.getIndexList().get(c);
							if(grad_visited.get(idx)==0)
							{	
								V.add(idx,
										f,
										lRate
												* (cmg * grad.get(idx) -  regK2
														* V.get(idx, f)));
								grad_visited.set(idx, 1);
//								loss+=regK2*V.get(idx, f)*V.get(idx, f);
							}
						}
						for (int c = 0; c < x_j.size(); c++) {
							int idx=x_j.getIndexList().get(c);
							if(grad_visited.get(idx)==0)
							{
								V.add(idx,
										f,
										lRate
												* (cmg * grad.get(idx) - regK2
														* V.get(idx, f)));
								grad_visited.set(idx, 1);
//								loss+=regK2*V.get(idx, f)*V.get(idx, f);
							}
						}
					}
				}
			}
			if (isConverged(iter))
				break;
		}
	}

	@Override
	public String toString() {
		return Strings.toString(new Object[] { lossf,epsilon, binThold, numFactors, initLRate, maxLRate, k0, k1 , k2,regK0, regK1, regK2, numIters }, ",");
	}
	protected double predict(SparseVector x) throws Exception {
		return super.predict(x);
	}
	private DenseVector sum( SparseVector x) {
		DenseVector sum=new DenseVector(numFactors);
		// TODO Auto-generated method stub
		for (int f = 0; f < numFactors; f++) {
			double sum_f = 0;
			sum.set(f, 0);
			for (int i = 0; i < x.size(); i++) {
				int idx = x.getIndexList().get(i);
				double d = V.get(idx, f) * x.get(idx);
				sum_f += d;
				sum.set(f, sum_f);
			}
		}
		return sum;
	}

}
